package com.src.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="STUDENT")
public class Student {

	@Id
	@Column(name="StudentName")
	private String StudentName;
	private String RegisterNo;
	
	private int year;
	
	private String Department;
	
	
	public int getyear() {
		return year;
	}

	public void setyear(int year) {
		this.year = year;
	}

	public String getName() {
		return StudentName;
	}

	public void setName(String Name) {
		this.StudentName = Name;
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String Department) {
		this.Department = Department;
	}

	public String getRegisterNo() {
		return RegisterNo;
	}

	public void setRegisterNo(String RegisterNo) {
		this.RegisterNo = RegisterNo;
	}

	
	@Override
	public String toString() {
		return "Train [Name=" + StudentName + ", Register No=" + RegisterNo + ", Year=" + year + ", Department=" + Department  + "]";
	}


	
}
