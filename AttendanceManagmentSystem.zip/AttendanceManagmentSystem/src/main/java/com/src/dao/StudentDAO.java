package com.src.dao;

import java.util.List;

import com.src.model.Student;


public interface StudentDAO {

	public void addStudent(Student t);
	public void updateStudent(Student t);
	public List<Student> listStudents();
	public Student getStudentByRegisterNo(String regno);
	public void removeStudent(String regno);
}
