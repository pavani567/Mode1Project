package com.src.dao;

import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.src.model.Student;


@Repository
public class StudentDAOImpl implements StudentDAO{

    @Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}

	@Override
	public void addStudent(Student t) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(t);
		//logger.info("Train saved successfully, Train Details="+t);
	}

	@Override
	public void updateStudent(Student t) {
		Session session = this.sessionFactory.getCurrentSession();
		session.update(t);
	//	logger.info("Train updated successfully, Train Details="+t);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Student> listStudents() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Student> studentsList = session.createQuery("from Student").list();
		for(Student t : studentsList){
		//	logger.info("Student List::"+t);
		}
		return studentsList;
	}

	@Override
	public Student getStudentByRegisterNo(String regno) {
		Session session = this.sessionFactory.getCurrentSession();		
		Student t = (Student) session.load(Student.class, new String(regno));
		//logger.info("Student loaded successfully, Student details="+t);
		return t;
	}

	@Override
	public void removeStudent(String regno) {
		Session session = this.sessionFactory.getCurrentSession();
		Student t = (Student) session.load(Student.class, new String(regno));
		if(null != t){
			session.delete(t);
		}
		//logger.info("Student deleted successfully, Student details="+t);
	}
	
}
