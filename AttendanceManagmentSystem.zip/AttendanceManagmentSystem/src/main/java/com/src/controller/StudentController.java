package com.src.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.src.model.Student;

import com.src.service.StudentService;


@Controller
public class StudentController {
	private static final Logger logger = Logger
			.getLogger(UserController.class);

	public StudentController() {
		System.out.println("StudentController()");
	}
	@Autowired
	private StudentService studentService;
	
	/*@RequestMapping(value="/student",method=RequestMethod.GET )
	public String book()
	{
		
		return "student";
	}*/
	
	@RequestMapping(value="/addstudent",method=RequestMethod.GET )
	public String addTrain1(@ModelAttribute("Student") Student student,ModelAndView model)
	{
		
		studentService.create(student);
		return "redirect:/student";
	}
	
	@RequestMapping(value="/displaystudentlist",method=RequestMethod.GET )
	public String display()
	{
		
		return "displaystudentlist";
	}
	
	
	@RequestMapping(value="/Booknow",method=RequestMethod.GET )
	public String book()
	{
		
		return "Booknow";
	}
	
	
	@RequestMapping(value="/studentdetails",method=RequestMethod.GET )
	public String passengerdisplay()
	{
		
		return "studentdetails";
	}
	


	@RequestMapping(value = "/student", method = RequestMethod.GET)
	public String listTrains(Model model) {
		model.addAttribute("student", new Student());
		model.addAttribute("listStudents", this.studentService.listStudents());
		return "student";
	}
	
}
