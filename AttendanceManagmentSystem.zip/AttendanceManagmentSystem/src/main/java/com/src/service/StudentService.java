package com.src.service;

import java.util.List;

import com.src.model.Student;


public interface StudentService {

	public void addStudent(Student t);
	public void updateStudent(Student t);
	public List<Student> listStudents();
	public Student getStudentByRegisterNo(String regno);
	public void removeStudent(String regno);
	public void create(Student student);
	public List<Student> findAll();
	public Object find(String RegisterNo, String Name, int year, String Department);


}
