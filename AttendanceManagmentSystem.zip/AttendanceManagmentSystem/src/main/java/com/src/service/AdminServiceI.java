package com.src.service;

import java.util.List;

import com.src.model.Admin;

public interface AdminServiceI {

	
	public boolean validate(Admin ad);

	public List<Admin> findAll();

	public Object find(String RegisterNo, String Name, int year, String Department);

	public void updateStudent(Admin student);

	public void create(Object student);

	public Object listStudents();

	
	
}
