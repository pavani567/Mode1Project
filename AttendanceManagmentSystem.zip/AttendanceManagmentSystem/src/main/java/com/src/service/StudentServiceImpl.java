package com.src.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.StudentDAO;
import com.src.model.Student;


@Service
public class StudentServiceImpl implements StudentService{
    @Autowired
	private StudentDAO studentDAO;

	public void setStudentDAO(StudentDAO studentDAO) {
		this.studentDAO = studentDAO;
	}

	@Override
	@Transactional
	public void addStudent(Student t) {
		this.studentDAO.addStudent(t);
	}

	@Override
	@Transactional
	public void updateStudent(Student t) {
		this.studentDAO.updateStudent(t);
	}

	@Override
	@Transactional
	public List<Student> listStudents() {
		return this.studentDAO.listStudents();
	}

	@Override
	@Transactional
	public Student getStudentByRegisterNo(String regno) {
		return this.studentDAO.getStudentByRegisterNo(regno);
	}

	@Override
	@Transactional
	public void removeStudent(String regno) {
		this.studentDAO.removeStudent(regno);
		Student student = null;
		this.studentDAO.addStudent(student);

	}

	@Override
	@Transactional

	public void create(Student student) {
		// TODO Auto-generated method stub
		this.studentDAO.addStudent(student);
	}

	@Override
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object find(String RegisterNo, String Name, int year, String Department) {
		// TODO Auto-generated method stub
		return null;
	}
}
