package com.src.service;

import com.src.model.User;

public interface UserService {

	public boolean validate1(User user);

}
